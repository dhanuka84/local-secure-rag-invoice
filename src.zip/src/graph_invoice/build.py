from langgraph.graph import StateGraph, END
from .nodes import (
    node_load_pdf,
    node_extract_text,
    node_milvus_suggest,
    node_learn_template,
    node_apply_template,
    node_extract_fields,
    node_vision_validate,
    node_auto_refine_template,
    node_promote_template,
    node_needs_review,
    should_learn_or_use,
    should_pass_or_review,
)

def build_invoice_graph():

    g = StateGraph()

    # --- Nodes ---
    g.add_node("load_pdf", node_load_pdf)
    g.add_node("extract_text", node_extract_text)
    g.add_node("milvus_suggest", node_milvus_suggest)
    g.add_node("learn_template", node_learn_template)
    g.add_node("apply_template", node_apply_template)
    g.add_node("extract_fields", node_extract_fields)
    g.add_node("vision_validate", node_vision_validate)
    g.add_node("auto_refine_template", node_auto_refine_template)
    g.add_node("promote_template", node_promote_template)
    g.add_node("needs_review", node_needs_review)

    # --- Flow ---
    g.set_entry_point("load_pdf")
    g.add_edge("load_pdf", "extract_text")
    g.add_edge("extract_text", "milvus_suggest")

    # Learn vs reuse existing template
    g.add_conditional_edges(
        "milvus_suggest",
        should_learn_or_use,
        {
            "learn": "learn_template",
            "use": "apply_template",
        },
    )

    # After learning → apply template
    g.add_edge("learn_template", "apply_template")

    # After applying → extract fields
    g.add_edge("apply_template", "extract_fields")

    # Validate with vision
    g.add_edge("extract_fields", "vision_validate")

    # Decide next step based on vision + consistency
    g.add_conditional_edges(
        "vision_validate",
        should_pass_or_review,
        {
            "pass": "promote_template",
            "review": "auto_refine_template",
            "review_final": "needs_review",
        },
    )

    # If refined → run extraction again
    g.add_edge("auto_refine_template", "extract_fields")

    # End of pipeline
    g.add_edge("promote_template", END)
    g.add_edge("needs_review", END)

    return g
