from langgraph.graph import StateGraph, START, END

from .state import InvoiceState
from .nodes import (
    # Core extraction
    node_extract_pdf,
    node_ocr_if_needed,
    node_signature,
    node_check_cache,
    # Decisions
    should_reuse_or_search,
    node_milvus_suggest,
    should_use_suggest_or_learn,
    # Template-based extraction (Tesseract + regex)
    node_learn_and_stage,
    node_extract_fields,
    # OPTIONAL: LayoutLM hybrid validation (no Donut)
    node_hybrid_extract_fields,
    # Vision + promotion
    node_vision_validate,
    should_pass_or_review,
    node_promote_template,
    node_mark_for_review,
    node_done,
)


def build_invoice_graph():
    """
    Tesseract + regex + (optional) LayoutLM graph.
    NO Donut / DocVLM is used.

    Flow:

      START
        -> extract_pdf          (pdf_to_text_and_images)
        -> ocr_if_needed        (Tesseract, lang="swe")
        -> signature
        -> check_cache
        -> (reuse | search)     via should_reuse_or_search

      If reuse (active template found):
        -> extract_fields       (regex)
        -> hybrid_extract_fields
        -> vision_validate
        -> (promote_template | mark_for_review)
        -> done -> END

      If search (no active template):
        -> milvus_suggest
        -> (suggested | learn)  via should_use_suggest_or_learn

        If suggested:
          -> extract_fields
          -> hybrid_extract_fields
          -> vision_validate
          -> (promote_template | mark_for_review)
          -> done -> END

        If learn:
          -> learn_and_stage    (learn_regexes from OCR text)
          -> extract_fields     (use newly learned template)
          -> hybrid_extract_fields
          -> vision_validate
          -> (promote_template | mark_for_review)
          -> done -> END
    """

    g = StateGraph(InvoiceState)

    # ---------- Nodes ----------

    # Core pipeline
    g.add_node("extract_pdf", node_extract_pdf)
    g.add_node("ocr_if_needed", node_ocr_if_needed)
    g.add_node("signature", node_signature)
    g.add_node("check_cache", node_check_cache)

    # Similarity / search (Milvus)
    g.add_node("milvus_suggest", node_milvus_suggest)

    # Template-based extraction (regex)
    g.add_node("learn_and_stage", node_learn_and_stage)
    g.add_node("extract_fields", node_extract_fields)

    # LayoutLM hybrid (no Donut) – optional but enabled
    g.add_node("hybrid_extract_fields", node_hybrid_extract_fields)

    # Vision validation
    g.add_node("vision_validate", node_vision_validate)

    # Promotion / review
    g.add_node("promote_template", node_promote_template)
    g.add_node("mark_for_review", node_mark_for_review)

    # Final
    g.add_node("done", node_done)

    # ---------- Edges ----------

    # Entry
    g.add_edge(START, "extract_pdf")
    g.add_edge("extract_pdf", "ocr_if_needed")
    g.add_edge("ocr_if_needed", "signature")
    g.add_edge("signature", "check_cache")

    # Reuse vs search
    g.add_conditional_edges(
        "check_cache",
        should_reuse_or_search,  # returns "reuse" or "search"
        {
            "reuse": "extract_fields",
            "search": "milvus_suggest",
        },
    )

    # Milvus suggestions: suggested template vs learn new template
    g.add_conditional_edges(
        "milvus_suggest",
        should_use_suggest_or_learn,  # returns "suggested" or "learn"
        {
            "suggested": "extract_fields",
            "learn": "learn_and_stage",   # 👈 no doc_vlm here
        },
    )

    # Learn path: learn template from OCR text, then extract fields
    g.add_edge("learn_and_stage", "extract_fields")

    # After regex extraction, run LayoutLM hybrid (for validation/score)
    g.add_edge("extract_fields", "hybrid_extract_fields")

    # Hybrid → vision
    g.add_edge("hybrid_extract_fields", "vision_validate")

    # Vision → promote vs review
    g.add_conditional_edges(
        "vision_validate",
        should_pass_or_review,  # returns "pass" or "review"
        {
            "pass": "promote_template",
            "review": "mark_for_review",
        },
    )

    g.add_edge("promote_template", "done")
    g.add_edge("mark_for_review", "done")

    g.add_edge("done", END)

    return g.compile()
