import os
import json
import math
import re
from typing import Any, Dict, Optional, List

from src.invoice.pdf_io import pdf_to_text_and_images, ocr_if_needed
from src.invoice.signature import build_signature
from src.invoice.template_cache import TemplateCache
from src.invoice.extract import extract_fields
from src.invoice.template_learner import learn_regexes
from src.invoice.vision_validate import validate_with_vision
from src.invoice.cerbos_client import can_promote_template
from src.invoice.metrics import TemplateMetrics
from src.invoice.layoutlm_extract import extract_with_layoutlm
from src.invoice.spacy_extract import extract_with_spacy

from langchain_ollama.embeddings import OllamaEmbeddings
from src.invoice.template_learner import refine_regexes
from pymilvus import connections, utility, FieldSchema, CollectionSchema, DataType, Collection


COLL = "invoice_templates"

def _normalize_number(value: str | None) -> float | None:
    if not value:
        return None
    import re
    cleaned = re.sub(r"[^0-9.,-]", "", value)
    if not cleaned:
        return None
    cleaned = cleaned.replace(",", ".")
    try:
        return float(cleaned)
    except ValueError:
        return None


def node_hybrid_extract_fields(state: dict) -> dict:
    """
    Combine Donut (doc_vlm) + LayoutLMv3 extraction and compute a validation score.
    Assumes doc_vlm already ran and filled state["fields"] and/or state["ml_line_items"].
    """
    pdf_path = state.get("pdf_path") or state.get("pdf")

    doc_fields = state.get("fields") or {}
    doc_items = state.get("ml_line_items") or []

    lm_result = extract_with_layoutlm(pdf_path)
    lm_fields = lm_result.get("fields") or {}
    lm_items = lm_result.get("line_items") or []

    # --- Merge fields (simple voting/priority rule) ---
    merged = dict(doc_fields)  # start from Donut

    def choose(key: str) -> str | None:
        a = (doc_fields or {}).get(key)
        b = (lm_fields or {}).get(key)
        # Prefer exact agreement
        if a and b and str(a) == str(b):
            return a
        # Otherwise prefer LayoutLM for invoice_no/date,
        # and Donut for totals (tune as you wish)
        if key in ("invoice_no", "date"):
            return b or a
        if key in ("total", "subtotal", "tax", "tax_rate"):
            return a or b
        return a or b

    for key in ["invoice_no", "date", "subtotal", "tax", "total", "tax_rate"]:
        merged[key] = choose(key)

    # --- Numeric validation: subtotal + tax ≈ total ---
    total = _normalize_number(merged.get("total"))
    subtotal = _normalize_number(merged.get("subtotal"))
    tax = _normalize_number(merged.get("tax"))

    math_ok = None
    if subtotal is not None and tax is not None and total is not None:
        if abs((subtotal + tax) - total) <= 0.01 * max(total, 1.0):
            math_ok = True
        else:
            math_ok = False

    # --- Agreement checks between models ---
    agree_total = None
    if doc_fields.get("total") and lm_fields.get("total"):
        agree_total = (
            _normalize_number(doc_fields["total"]) ==
            _normalize_number(lm_fields["total"])
        )

    agree_date = None
    if doc_fields.get("date") and lm_fields.get("date"):
        agree_date = (str(doc_fields["date"]) == str(lm_fields["date"]))

    agree_invoice = None
    if doc_fields.get("invoice_no") and lm_fields.get("invoice_no"):
        agree_invoice = (str(doc_fields["invoice_no"]) == str(lm_fields["invoice_no"]))

    # --- Build an ML validation score [0,1] ---
    score = 0.0
    components = 0

    if agree_total is not None:
        components += 1
        if agree_total:
            score += 0.3

    if agree_date is not None:
        components += 1
        if agree_date:
            score += 0.2

    if agree_invoice is not None:
        components += 1
        if agree_invoice:
            score += 0.2

    if math_ok is not None:
        components += 1
        if math_ok:
            score += 0.3

    if components > 0:
        score = min(1.0, score)  # already normalized by weights
    else:
        score = 0.0

    # --- Write back to state ---
    state["fields"] = merged
    # Combine line items (just concatenate for now)
    state["ml_line_items"] = (doc_items or []) + (lm_items or [])
    state["layoutlm_raw"] = lm_result.get("raw_tokens")
    state["ml_validation_score"] = score

    return state


def _milvus_connect():
    connections.connect("default", host="localhost", port="19530")

def _milvus_ensure(dim: int = 768):
    if not utility.has_collection(COLL):
        fields = [
            FieldSchema(name="signature", dtype=DataType.VARCHAR, is_primary=True, max_length=128),
            FieldSchema(name="vendor", dtype=DataType.VARCHAR, max_length=128),
            FieldSchema(name="vec", dtype=DataType.FLOAT_VECTOR, dim=dim),
        ]
        schema = CollectionSchema(fields, "invoice template embeddings")
        Collection(COLL, schema, shards_num=1)
    c = Collection(COLL)
    if not any(i.field_name == "vec" for i in c.indexes):
        c.create_index(field_name="vec", index_params={"index_type":"HNSW","metric_type":"IP","params":{"M":16,"efConstruction":200}})
    c.load()

def _milvus_embed(signature: str, vendor: str) -> List[float]:
    emb = OllamaEmbeddings(model="nomic-embed-text")
    return emb.embed_query(f"template signature {signature} vendor {vendor}")

def _milvus_upsert(signature: str, vendor: str):
    c = Collection(COLL)
    vec = _milvus_embed(signature, vendor)
    c.insert([[signature],[vendor],[vec]])
    c.flush(); c.load()

def _milvus_suggest(signature: str, vendor: str, top_k: int = 3) -> List[str]:
    c = Collection(COLL)
    qvec = [_milvus_embed(signature, vendor)]
    res = c.search(data=qvec, anns_field="vec", param={"metric_type":"IP","params":{"ef":64}},
                   limit=top_k, output_fields=["signature"])
    out = []
    for hit in res[0]:
        out.append(hit.entity.get("signature"))
    return out

def node_extract_pdf(state):
    text, images = pdf_to_text_and_images(state["pdf_path"])
    state["text"], state["images"] = text, images
    return state

def node_ocr_if_needed(state):
    state["text"] = ocr_if_needed(state["text"], state.get("images", []))
    return state

def node_signature(state):
    sig = build_signature(state["text"])
    state["signature"] = sig
    vendor = next((l.strip() for l in state["text"].splitlines() if l.strip()), "unknown")
    state["vendor"] = vendor[:64]
    return state

def node_check_cache(state):
    cache = TemplateCache()
    active = cache.get_active(state["signature"])
    staging = cache.get_staging(state["signature"])
    state["template_active"] = active
    state["template_staging"] = staging
    if active:
        state["template"] = active; state["template_source"] = "active"
    elif staging:
        state["template"] = staging; state["template_source"] = "staging"
    else:
        state["template"] = None; state["template_source"] = "none"
    return state

def should_reuse_or_search(state: dict) -> str:
    """
    Decide whether to reuse a template or run the search/learn path.

    We ONLY reuse templates that are already ACTIVE.
    Staging/learned templates still go through the "search" path,
    which can hit Donut + learning again.
    """
    template_source = state.get("template_source")

    if template_source == "active":
        return "reuse"
    else:
        # "staging", "learned", None, etc.
        return "search"


def node_milvus_suggest(state):
    _milvus_connect(); _milvus_ensure()
    sig, vendor = state["signature"], state["vendor"]
    _milvus_upsert(sig, vendor)
    state["suggested_signatures"] = _milvus_suggest(sig, vendor, top_k=3)
    return state

def should_use_suggest_or_learn(state) -> str:
    cache = TemplateCache()
    for s in state.get("suggested_signatures", []):
        t = cache.get_active(s) or cache.get_staging(s)
        if t:
            state["template"] = t
            state["template_source"] = "suggested"
            return "suggested"
    return "learn"

def node_learn_and_stage(state):
    tmpl = learn_regexes(state["text"])
    cache = TemplateCache()
    cache.set_staging(state["signature"], tmpl)
    state["template"] = tmpl
    state["template_source"] = "learned"
    return state


def node_extract_fields(state):
    from src.invoice.extract import extract_fields
    fields = extract_fields(state["text"], state["template"])
    state["fields"] = fields

    from decimal import Decimal

    sub = fields.get("subtotal")
    tax = fields.get("tax")
    tot = fields.get("total")

    def _to_dec(x):
        if x is None:
            return None
        return Decimal(str(x))

    sd, td, Td = _to_dec(sub), _to_dec(tax), _to_dec(tot)

    consistent = True
    expected_total = None
    if sd is not None and td is not None:
        expected_total = sd + td
        if Td is not None and (Td - expected_total).copy_abs() > _to_dec("0.01"):
            consistent = False

    state["fields_consistent"] = consistent
    state["expected_total"] = str(expected_total) if expected_total is not None else None
    return state



import re
from decimal import Decimal, InvalidOperation

def _to_swedish_amount(value) -> str | None:
    """
    Convert dot-decimal numbers (172.00) to Swedish comma-decimal format (172,00 kr)
    for the vision model.
    """
    if value is None:
        return None
    s = str(value).strip()
    if re.match(r"^-?\d+(\.\d+)?$", s):
        s = s.replace(".", ",")
    return f"{s} kr"


def node_vision_validate(state: dict) -> dict:
    """
    Hybrid vision validation:
      1. Call the vision model with Swedish-formatted values.
      2. If our extracted fields are complete and math-consistent,
         override the model and mark this as a strong PASS.
    """
    from src.invoice.vision_validate import validate_with_vision

    # WARNING: at this stage, fields still use ENGLISH keys
    # (invoice_no, date, subtotal, tax, total, tax_rate).
    # They are only renamed to Swedish in node_done.
    fields = state.get("fields") or {}

    # --- 1) Prepare payload for vision model (Swedish formatting) ---
    vis_fields = {}
    for k, v in fields.items():
        if k in ("subtotal", "tax", "total"):
            vis_fields[k] = _to_swedish_amount(v)
        elif k == "tax_rate":
            # convert 0.25 -> "25%"
            try:
                rate = float(str(v).replace(",", "."))
                vis_fields[k] = f"{int(rate * 100)}%"
            except Exception:
                vis_fields[k] = str(v) if v is not None else None
        else:
            vis_fields[k] = str(v) if v is not None else None

    verdict = validate_with_vision(vis_fields, state.get("images", []))

    vpass = bool(verdict.get("pass"))
    vscore = float(verdict.get("score", 0.0))
    vcrit = verdict.get("critique", "")

    # --- 2) Deterministic override based on extracted fields ---
    def _dec(x):
        if x is None:
            return None
        try:
            return Decimal(str(x))
        except (InvalidOperation, ValueError):
            return None

    core_ok = all(fields.get(k) for k in ("invoice_no", "date", "subtotal", "tax", "total"))

    sub = _dec(fields.get("subtotal"))
    tax = _dec(fields.get("tax"))
    tot = _dec(fields.get("total"))

    math_ok = False
    if sub is not None and tax is not None and tot is not None:
        diff = (sub + tax) - tot
        # allow some öre rounding tolerance
        math_ok = diff.copy_abs() <= Decimal("0.50")

    if core_ok and math_ok:
        # We trust our extraction more than the raw VLM score.
        vpass = True
        if vscore < 0.9:
            vscore = 0.95
        if not vcrit:
            vcrit = "Fields are complete and subtotal + moms ≈ totalt belopp."

    state["vision_pass"] = vpass
    state["vision_score"] = vscore
    state["vision_critique"] = vcrit
    state["vision_fields_payload"] = vis_fields  # debug

    return state


def should_pass_or_review(state: dict) -> str:
    """
    Decide whether this run should be treated as pass or review.

    For the Tesseract+regex pipeline, we consider a run 'good' if:
      - all core fields are present, and
      - the math is consistent (subtotal + tax ≈ total).

    Vision/VLM score is optional; we treat it as advisory only.
    """
    fields = state.get("fields") or {}

    core_ok = all(
        fields.get(k)
        for k in ["invoice_no", "date", "subtotal", "tax", "total"]
    )

    # Check math consistency if we can
    from src.graph_invoice.nodes import _normalize_number  # or move helper out if needed

    subtotal = _normalize_number(str(fields.get("subtotal")))
    tax = _normalize_number(str(fields.get("tax")))
    total = _normalize_number(str(fields.get("total")))

    math_ok = None
    if subtotal is not None and tax is not None and total is not None:
        math_ok = abs((subtotal + tax) - total) <= 0.01 * max(total, 1.0)

    # Final decision
    if core_ok and (math_ok in (None, True)):
        # Force a "pass"
        state["vision_pass"] = True
        # If no vision_score was set, give it a 1.0 as a deterministic success
        if state.get("vision_score") is None:
            state["vision_score"] = 1.0
        state["combined_validation_score"] = 1.0
        return "pass"
    else:
        state["vision_pass"] = False
        state["combined_validation_score"] = 0.0
        return "review"



def node_done(state):
    """
    Final node. Optionally records success metrics.
    """
    sig = state.get("signature")
    if sig:
        # Consider a run "successful" if:
        #   - vision_pass is True
        #   - we have fields
        vpass = state.get("vision_pass", False)
        fields = state.get("fields") or {}
        if vpass and fields:
            TemplateMetrics().record_success(sig)

    state["done"] = True
    return state


import os
from src.invoice.template_cache import TemplateCache
from src.invoice.metrics import TemplateMetrics

DOCVLM_DEBUG = os.getenv('DOCVLM_DEBUG', 'false').lower() == 'true'
from src.invoice.cerbos_client import can_promote_template

AUTO_PROMOTE_THRESHOLD = int(os.getenv("AUTO_PROMOTE_THRESHOLD", "3"))


def node_promote_template(state: dict) -> dict:
    sig = state.get("signature")
    stage = state.get("template_source", "staging")
    role = state.get("role") or os.getenv("APP_ROLE", "employee")

    cache = TemplateCache()
    metrics = TemplateMetrics()

    # 🔹 1) If already active, do NOT try to promote again
    if stage == "active":
        # Keep previous status if it was "promoted", otherwise mark as already_active
        state.setdefault("promotion_status", "already_active")
        return state

    # 🔹 2) Read and normalize success_count
    m = metrics.get(sig) if sig else {}
    raw_success = m.get("success_count", 0)
    try:
        success_count = int(raw_success)
    except (TypeError, ValueError):
        success_count = 0

    # 🔹 3) Respect AUTO_PROMOTE_THRESHOLD for non-active templates
    threshold = AUTO_PROMOTE_THRESHOLD
    if success_count < threshold:
        state["promotion_status"] = f"pending_success_{success_count}"
        return state

    # 🔹 4) Ask Cerbos if this role may promote this stage
    allowed = can_promote_template(role=role, stage=stage)
    if not allowed:
        state["promotion_status"] = "denied"
        return state

    # 🔹 5) Promote in cache
    promoted = cache.promote(sig)
    if promoted:
        state["template_source"] = "active"
        state["promotion_status"] = "promoted"
        metrics.record_promotion(sig)
    else:
        state["promotion_status"] = "promote_failed"

    return state



def _to_swedish_str(value) -> str | None:
    """
    Convert '172.00' -> '172,00' for final JSON fields.
    Does NOT add 'kr'.
    """
    if value is None:
        return None
    s = str(value).strip()
    # Only touch simple numeric formats
    if re.match(r"^-?\d+(\.\d+)?$", s):
        s = s.replace(".", ",")
    return s



def node_done(state: dict) -> dict:
    """
    Final node.
    - Records success metrics
    - Converts numeric fields to Swedish comma decimals WITH ' kr'
    - Converts tax_rate to '25%'
    - Renames output fields to Swedish labels
    """
    import re
    sig = state.get("signature")
    fields = state.get("fields") or {}

    # Success metric
    if sig:
        vpass = state.get("vision_pass", False)
        if vpass and fields:
            TemplateMetrics().record_success(sig)

    # Convert numeric money fields
    def _to_swedish_money(value):
        if value is None:
            return None
        s = str(value).strip()
        if re.match(r"^-?\d+(\.\d+)?$", s):
            s = s.replace(".", ",")
        return f"{s} kr"

    # Internal → Swedish formatting
    if fields.get("subtotal") is not None:
        fields["subtotal"] = _to_swedish_money(fields["subtotal"])
    if fields.get("tax") is not None:
        fields["tax"] = _to_swedish_money(fields["tax"])
    if fields.get("total") is not None:
        fields["total"] = _to_swedish_money(fields["total"])

    # Tax rate: convert 0.25 → "25%"
    if "tax_rate" in fields and fields["tax_rate"] is not None:
        try:
            rate = float(str(fields["tax_rate"]).replace(",", "."))
            fields["tax_rate"] = f"{int(rate * 100)}%"
        except Exception:
            fields["tax_rate"] = str(fields["tax_rate"])

    # Map English → Swedish keys
    swedish = {
        "invoice_no": "OCR-/fakturanummer",
        "date": "Fakturadatum",
        "subtotal": "Summa exkl moms",
        "tax": "Moms",
        "total": "Totalt belopp",
        "tax_rate": "Moms (%)"
    }

    swedish_fields = {}
    for eng_key, swe_key in swedish.items():
        if eng_key in fields:
            swedish_fields[swe_key] = fields[eng_key]

    # Replace state fields with Swedish keys
    state["fields"] = swedish_fields
    state["done"] = True
    return state


def node_mark_for_review(state):
    state["done"] = False
    return state


def node_auto_refine_template(state):
    """If fields are inconsistent or vision failed, try to refine the template once."""
    tmpl = state.get("template")
    if not tmpl:
        state["auto_refine_status"] = "no_template"
        return state

    attempts = int(state.get("refine_attempts", 0))
    if attempts >= 1:
        state["auto_refine_status"] = "skipped_max_attempts"
        return state

    fields = state.get("fields", {}) or {}
    consistent = bool(state.get("fields_consistent", True))
    vision_pass = bool(state.get("vision_pass", False))
    expected_total = state.get("expected_total")
    current_total = fields.get("total")

    if consistent and vision_pass:
        state["auto_refine_status"] = "skipped_no_error"
        state["refine_attempts"] = attempts + 1
        return state

    if not expected_total or not current_total or str(expected_total) == str(current_total):
        state["auto_refine_status"] = "skipped_no_total_hint"
        state["refine_attempts"] = attempts + 1
        return state

    new_tmpl = refine_regexes(
        invoice_text=state["text"],
        current_template=tmpl,
        field_name="total",
        expected=str(expected_total),
        got=str(current_total),
    )

    sig = state.get("signature")
    if sig:
        from src.invoice.template_cache import TemplateCache
        TemplateCache().set_staging(sig, new_tmpl)
        TemplateMetrics().record_refine(sig)

    state["template"] = new_tmpl
    state["template_source"] = "refined"
    state["refine_attempts"] = attempts + 1
    state["auto_refine_status"] = "refined_total"
    return state


def node_doc_vlm_extract_fields(state: dict) -> dict:
    pdf_path = state.get("pdf_path") or state.get("pdf")

    if DOCVLM_DEBUG:
        print("------ DOCVLM NODE CALLED ------")
        print("PDF:", pdf_path)

    if not pdf_path:
        state.setdefault("fields", {})
        state.setdefault("ml_line_items", [])
        state["template_source"] = "doc_vlm"
        return state

    result = extract_with_doc_vlm(pdf_path)

    if DOCVLM_DEBUG:
        print("------ RAW DONUT SEQUENCE ------")
        print(result.get("model_output"))
        print("------ DONUT JSON ------")
        try:
            print(json.dumps(result.get("raw"), ensure_ascii=False, indent=2))
        except Exception:
            print(result.get("raw"))

    fields = result.get("fields") or {}
    line_items = result.get("line_items") or []

    current = state.get("fields") or {}
    current.update({
        "invoice_no": fields.get("invoice_no", current.get("invoice_no")),
        "date": fields.get("date", current.get("date")),
        "subtotal": fields.get("subtotal", current.get("subtotal")),
        "tax": fields.get("tax", current.get("tax")),
        "total": fields.get("total", current.get("total")),
        "tax_rate": fields.get("tax_rate", current.get("tax_rate")),
    })
    state["fields"] = current
    state["ml_line_items"] = line_items

    state["doc_vlm_raw"] = result.get("raw")
    state["doc_vlm_output"] = result.get("model_output")
    state["template_source"] = "doc_vlm"
    return state
