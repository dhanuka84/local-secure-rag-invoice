import re
import decimal
from typing import Dict, Optional


def _find(pattern: str, text: str) -> Optional[str]:
    if not pattern:
        return None
    m = re.search(pattern, text, flags=re.IGNORECASE)
    if not m:
        return None
    groups = [g for g in m.groups() if g]
    return groups[-1] if groups else m.group(0)


def parse_amount(s: Optional[str]) -> Optional[decimal.Decimal]:
    if not s:
        return None
    s = s.strip()
    cleaned = re.sub(r"[^0-9,.\-]", "", s)
    if not cleaned:
        return None
    if "," in cleaned and "." in cleaned:
        cleaned = cleaned.replace(",", "")
    elif "," in cleaned:
        cleaned = cleaned.replace(".", "")
        cleaned = cleaned.replace(",", ".")
    try:
        return decimal.Decimal(cleaned)
    except Exception:
        return None


SWED_INVOICE_NO_RE = re.compile(r"OCR[-/ ]*fakturanummer[:\s]*([0-9]{6,})", re.IGNORECASE)
SWED_FAKTURADATUM_RE = re.compile(r"Fakturadatum[:\s]*([0-9]{4}-[0-9]{2}-[0-9]{2})", re.IGNORECASE)
SWED_SUBTOTAL_RE = re.compile(r"Summa\s+exkl\s+moms\s+([\d\s]+[,.]\d{2})\s*kr", re.IGNORECASE)
SWED_TAX_RE = re.compile(r"Moms\s*\(\s*(\d+)\s*%\s*\)\s+([\d\s]+[,.]\d{2})\s*kr", re.IGNORECASE)
SWED_TOTAL_RE = re.compile(r"Totalt\s+belopp\s+([\d\s]+[,.]\d{2})\s*kr", re.IGNORECASE)


def fallback_extract_swedish_invoice(text: str) -> Dict[str, Optional[str]]:
    fields: Dict[str, Optional[str]] = {
        "invoice_no": None,
        "date": None,
        "subtotal": None,
        "tax": None,
        "total": None,
        "tax_rate": None,
    }

    # Invoice No
    m = SWED_INVOICE_NO_RE.search(text)
    if m:
        fields["invoice_no"] = m.group(1).strip()

    # Invoice date
    m = SWED_FAKTURADATUM_RE.search(text)
    if m:
        fields["date"] = m.group(1).strip()

    # Subtotal
    m = SWED_SUBTOTAL_RE.search(text)
    if m:
        fields["subtotal"] = m.group(1).strip()

    # Tax + rate
    m = SWED_TAX_RE.search(text)
    if m:
        rate_str, tax_str = m.group(1).strip(), m.group(2).strip()
        fields["tax"] = tax_str
        try:
            fields["tax_rate"] = str(int(rate_str) / 100.0)
        except Exception:
            pass

    # 1) Simple "Totalt belopp 172,00 kr"
    m = SWED_TOTAL_RE.search(text)
    if m:
        fields["total"] = m.group(1).strip()

    # 2) Summary block totals row (correct 172,00 kr result)
    if not fields["total"]:
        totals_row = re.search(
            r"\b\d{4}-\d{2}-\d{2}\b\s+[\d\s]+[,.]\d{2}\s*kr\s+[\d\s]+[,.]\d{2}\s*kr\s+[\d\s]+[,.]\d{2}\s*kr\s+([\d\s]+[,.]\d{2})\s*kr",
            text,
            re.IGNORECASE,
        )
        if totals_row:
            fields["total"] = totals_row.group(1).strip()

    return fields



def extract_fields(text: str, template: Dict) -> Dict:
    # --- Ensure template is dict-like ---
    if not isinstance(template, dict):
        template = {}

    rx = template.get("regex", {})

    data = {
        "invoice_no": _find(rx.get("invoice_no", ""), text),
        "date": _find(rx.get("date", ""), text),
        "subtotal": parse_amount(_find(rx.get("subtotal", ""), text)),
        "tax": parse_amount(_find(rx.get("tax", ""), text)),
        "total": parse_amount(_find(rx.get("total", ""), text)),
        "tax_rate": None,  # IMPORTANT: initialize so we don't get KeyError
    }

    # … math consistency & tax_rate calculation (if you want template-based logic here) …

    # ===========================
    # Choose correct fallback extractor
    # ===========================
    if looks_like_taby_invoice(text):
        fallback = fallback_extract_taby_invoice(text)
    else:
        fallback = fallback_extract_swedish_invoice(text)


    if data["invoice_no"] is None and fallback.get("invoice_no"):
        data["invoice_no"] = fallback["invoice_no"]

    if data["date"] is None and fallback.get("date"):
        data["date"] = fallback["date"]

    for key in ["subtotal", "tax", "total"]:
        if data[key] is None and fallback.get(key):
            data[key] = parse_amount(fallback[key])

    if data["tax_rate"] is None and fallback.get("tax_rate"):
        try:
            data["tax_rate"] = decimal.Decimal(str(fallback["tax_rate"]))
        except Exception:
            data["tax_rate"] = None

    out = {
        "invoice_no": data["invoice_no"],
        "date": data["date"],
        "subtotal": str(data["subtotal"]) if data["subtotal"] is not None else None,
        "tax": str(data["tax"]) if data["tax"] is not None else None,
        "total": str(data["total"]) if data["total"] is not None else None,
        "tax_rate": str(data["tax_rate"]) if data["tax_rate"] is not None else None,
    }
    return out

import re
import decimal
from typing import Dict, Optional

###########################################################
# 0. Helper Functions (same as before)
###########################################################

def _safe_amount(value: Optional[str]) -> Optional[str]:
    """Normalize decimal + append ' kr'."""
    if not value:
        return None
    cleaned = value.replace(" ", "").replace(",", ".")
    try:
        amount = decimal.Decimal(cleaned)
        # format back into Swedish (comma decimal)
        s = str(amount)
        if "." in s:
            whole, dec = s.split(".")
            return f"{whole},{dec.zfill(2)} kr"
        else:
            return f"{s},00 kr"
    except:
        return None


###########################################################
# 1. Detect Täby-style invoices
###########################################################

def looks_like_taby_invoice(text: str) -> bool:
    """
    Täby invoices contain very reliable identifiers:
    - 'TÄBY KOMMUN'
    - 'Att betala i SEK'
    - 'Fakturanr'
    """
    t = text.upper()
    return (
        "TÄBY KOMMUN" in t
        or "ATT BETALA I SEK" in t
        or "FAKTURANR" in t
    )


###########################################################
# 2. Täby Invoice Extractor
###########################################################

TABY_DATE_RE = re.compile(r"\bDatum\s+([0-9]{4}-[0-9]{2}-[0-9]{2})", re.IGNORECASE)
TABY_INVOICE_NO_RE = re.compile(r"Fakturanr[:\s]*([0-9]{6,})", re.IGNORECASE)
TABY_OCR_RE = re.compile(r"OCR[- ]*refnr[:\s]*([0-9]{6,})", re.IGNORECASE)

TABY_TOTAL_RE = re.compile(
    r"Att\s+betala\s+i\s+SEK[:\s]*([0-9]+[.,]\d{2})",
    re.IGNORECASE
)

TABY_MOMS_RE = re.compile(
    r"\bMoms\s+([0-9]+[.,]\d{2})",
    re.IGNORECASE
)

# subtotal sometimes appears only inside the % moms breakdown
TABY_SUBTOTAL_RE = re.compile(
    r"0%\s+([0-9]+[.,]\d{2})",
    re.IGNORECASE
)


def fallback_extract_taby_invoice(text: str) -> Dict[str, Optional[str]]:
    fields = {
        "OCR-/fakturanummer": None,
        "Fakturadatum": None,
        "Summa exkl moms": None,
        "Moms": None,
        "Totalt belopp": None,
        "Moms (%)": None,
    }

    # --- Date ---
    m = TABY_DATE_RE.search(text)
    if m:
        fields["Fakturadatum"] = m.group(1)

    # --- Invoice number (OCR priority) ---
    m = TABY_OCR_RE.search(text)
    if m:
        fields["OCR-/fakturanummer"] = m.group(1)
    else:
        m = TABY_INVOICE_NO_RE.search(text)
        if m:
            fields["OCR-/fakturanummer"] = m.group(1)

    # --- Total ---
    m = TABY_TOTAL_RE.search(text)
    if m:
        fields["Totalt belopp"] = _safe_amount(m.group(1))

    # --- Moms ---
    m = TABY_MOMS_RE.search(text)
    if m:
        fields["Moms"] = _safe_amount(m.group(1))

    # --- Subtotal (from 0% line if present) ---
    m = TABY_SUBTOTAL_RE.search(text)
    if m:
        fields["Summa exkl moms"] = _safe_amount(m.group(1))

    # --- Moms (%) ---
    # Täby invoices show several %, but base rate is almost always 25%
    if "25.00% moms" in text:
        fields["Moms (%)"] = "25%"
    elif "12.00%" in text:
        fields["Moms (%)"] = "12%"
    elif "6.00%" in text:
        fields["Moms (%)"] = "6%"

    return fields

